"""Shell kodini bajarmasdan, oddiy KEY=value sozlamalarini o‘qish."""
from dataclasses import dataclass
import os
from pathlib import Path
import re
from urllib.parse import urlsplit

from security import SafeError


@dataclass
class Config:
    data_dir: Path
    enc_key: str
    mcp_secret: str
    public_url: str

    @property
    def host(self):
        return urlsplit(self.public_url).netloc


def load_env(path='.env'):
    path = Path(path)
    if path.exists():
        if path.is_symlink() or path.stat().st_mode & 0o077:
            raise SafeError('.env ruxsati 600 bo‘lishi kerak: chmod 600 .env')
        for raw in path.read_text().splitlines():
            line = raw.strip()
            if not line or line.startswith('#'):
                continue
            key, sep, value = line.partition('=')
            if not sep or not re.fullmatch(r'[A-Z_]+', key):
                raise SafeError('.env formati noto‘g‘ri.')
            os.environ.setdefault(key, value.strip().strip('\"\''))


def config():
    load_env()
    key, secret = os.getenv('ENC_KEY', ''), os.getenv('MCP_SECRET', '')
    if len(secret) < 43:
        raise SafeError('MCP_SECRET yetarli emas; avval python setup.py bajaring.')
    try:
        from cryptography.fernet import Fernet
        Fernet(key.encode())
    except (ValueError, TypeError):
        raise SafeError('ENC_KEY noto‘g‘ri; avval python setup.py bajaring.') from None
    url = os.getenv('PUBLIC_URL', 'https://localhost').rstrip('/')
    parts = urlsplit(url)
    if parts.scheme != 'https' or not parts.hostname or parts.username or parts.password or parts.path or parts.query or parts.fragment:
        raise SafeError('PUBLIC_URL faqat HTTPS domen bo‘lsin, yo‘lsiz.')
    return Config(Path(os.getenv('DATA_DIR', 'data')).absolute(), key, secret, url)
